File gdshader harus di taruh di bagian material di node color rect, 
File gdscript harus di taruh/di pasang di node Apapun yang jadi Camera pivot, ganti juga namanya jadi "head"
Bisa di atur di shader parameter yang ada di node color rect, mau berapa strength blur nya, mau berapa gambar yang mau di ulang (sebenernya nya efek blur ada banyak gambar di frame sebelum nya yang opacity nya berkurang)

Terimakasih sudah menggunakan asset ini 👍